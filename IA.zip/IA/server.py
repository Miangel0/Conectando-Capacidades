import os
import cv2
import numpy as np
from flask import Flask, request, jsonify
from keras.models import load_model
from mediapipe.python.solutions.holistic import Holistic
from helpers import normalize_keypoints, there_hand, extract_keypoints, mediapipe_detection, word_ids

app = Flask(__name__)
model = load_model("ruta/del/modelo.h5")
holistic_model = Holistic()

@app.route('/')
def hello():
    return 'Conectando Capacidades - IA para Lenguaje de Señas'

@app.route('/process_frame', methods=['POST'])
def process_frame():
    # Recibe un fotograma desde el frontend
    file = request.files['frame'].read()
    np_img = np.frombuffer(file, np.uint8)
    frame = cv2.imdecode(np_img, cv2.IMREAD_COLOR)
    
    # Procesa el fotograma usando mediapipe y el modelo
    results = mediapipe_detection(frame, holistic_model)
    if there_hand(results):
        kp_seq = [extract_keypoints(results)]
        kp_normalized = normalize_keypoints(kp_seq, modelo_frame_size)
        res = model.predict(np.expand_dims(kp_normalized, axis=0))[0]
        
        if res[np.argmax(res)] > 0.7:
            prediction = word_ids[np.argmax(res)].split('-')[0]
            return jsonify({'prediction': prediction})
    return jsonify({'prediction': None})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
